# 组件轮播图
## 1、framework.js
``` ruby
```


